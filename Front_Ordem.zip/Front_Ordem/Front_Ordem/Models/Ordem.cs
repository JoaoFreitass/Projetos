﻿namespace Front_Ordem.Models
{
    public class Ordem
    {
        public int ID { get; set; }

        public string Cliente { get; set; }


        public string Nchamado { get; set; }

        public string Comentario { get; set; }


        public string Descrição { get; set; }

        public string Status { get; set; }


        public string Responsabilidade { get; set; }

        public string TipoErro { get; set; }


        public string GrupoEncaminhado { get; set; }

        public string AnalistaResp { get; set; }
    }
}
