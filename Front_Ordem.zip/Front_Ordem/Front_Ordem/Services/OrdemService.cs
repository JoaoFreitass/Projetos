﻿using Front_Ordem.Models;
using Newtonsoft.Json;
using System.Net.Http.Headers;

namespace Front_Ordem.Services
{
    public class OrdemService : IOrdemService
    {

        HttpClient client = new HttpClient();
        private IConfiguration _configuration;
        public OrdemService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task<IEnumerable<Ordem>> GetOrdem()
        {
            List<Ordem>? list = new List<Ordem>();

            client.BaseAddress = new Uri(_configuration["APIEnd:Ordem"]);
            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.Accept.Add(
            new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            HttpResponseMessage response = await client.GetAsync("GetOrdem");

            if (response.IsSuccessStatusCode)
            {
                var dados = response.Content.ReadAsStringAsync().Result;
                list = JsonConvert.DeserializeObject<List<Ordem>>(dados);
            }
            return list;
        }

        public async Task<Ordem> Create(Ordem Ordem)
        {

            client.BaseAddress = new Uri(_configuration["APIEnd:Ordem"]);
            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.Accept.Add(
            new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            string json = JsonConvert.SerializeObject(Ordem);
            StringContent httpContent = new StringContent(json, System.Text.Encoding.UTF8, "application/json");


            HttpResponseMessage response = await client.PostAsync("Create", httpContent);

            if (response.IsSuccessStatusCode)
            {
                string sc = "Sucesso";
            }

            return Ordem;
        }

        public async Task<Ordem> GetOrdemById(int id)
        {
            List<Ordem>? list = new List<Ordem>();

            client.BaseAddress = new Uri(_configuration["APIEnd:Ordem"]);
            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.Accept.Add(
            new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            HttpResponseMessage response = await client.GetAsync("GetOrdem");
            Ordem prato = new Ordem();

            if (response.IsSuccessStatusCode)
            {
                var dados = response.Content.ReadAsStringAsync().Result;
                list = JsonConvert.DeserializeObject<List<Ordem>>(dados);
                prato = list.Find(x => x.ID == id);
            }
            return prato;
        }

        public async Task<Ordem> Update(Ordem ordem)
        {
            
            client.BaseAddress = new Uri(_configuration["APIEnd:Ordem"]);
            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.Accept.Add(
            new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            string json = JsonConvert.SerializeObject(ordem);
            StringContent httpContent = new StringContent(json, System.Text.Encoding.UTF8, "application/json");


            HttpResponseMessage response = await client.PutAsync($"Update/{ordem.ID}", httpContent);

            if (response.IsSuccessStatusCode)
            {
                string sc = "Sucesso";
            }

            return ordem;
        }

        public async Task<bool> Delete(int id)
        {
            //var id = await GetOrdemById(ordem.ID);

            client.BaseAddress = new Uri(_configuration["APIEnd:Ordem"]);
            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.Accept.Add(
            new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            string json = JsonConvert.SerializeObject(id);
            StringContent httpContent = new StringContent(json, System.Text.Encoding.UTF8, "application/json");


            HttpResponseMessage response = await client.DeleteAsync($"Delete/{id}");

            bool delete = false;
            if (response.IsSuccessStatusCode)
            {
                delete = true;
            }

            return delete;
        }



    }
}


