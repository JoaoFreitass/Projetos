﻿using Front_Ordem.Models;
using System.Runtime.Intrinsics.Arm;

namespace Front_Ordem.Services
{
    public interface IOrdemService
    {
        Task<IEnumerable<Ordem>> GetOrdem();
        Task<Ordem> GetOrdemById(int id);
        Task<Ordem> Create(Ordem ordem);
        Task<Ordem> Update(Ordem ordem);
        Task<bool> Delete(int ordem);
    }
}
