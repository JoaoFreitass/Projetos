﻿using Front_Ordem.Models;
using Front_Ordem.Services;
using Microsoft.AspNetCore.Mvc;

namespace Front_Ordem.Controllers
{
    public class OrdemController : Controller
    {
        private readonly IOrdemService _ordemService;

        public OrdemController(IOrdemService ordemService)
        {
            _ordemService = ordemService;
        }

        public async Task<IActionResult> Index()
        {
            var list = await _ordemService.GetOrdem();


            return View(list);
        }

        [HttpGet]
        public async Task<IActionResult> Detalhes(int id)
        {
            var lista = await _ordemService.GetOrdemById(id);

            return View(lista);
        }

        [HttpGet]
        public ActionResult Adicionar()
        {
            Ordem Novo = new Ordem();
            return View(Novo);
        }

        [HttpPost]
        public async Task<ActionResult> Adicionar(Ordem Novo)
        {

            var retorno = await _ordemService.Create(Novo);


            if (retorno != null)
                return RedirectToAction("Index");
            else
                throw new Exception("Error");
        }

        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            var lista = await _ordemService.GetOrdemById(id);

            return View(lista);
        }
        [HttpPost]
        public async Task<ActionResult> Delete(Ordem ordem, int id)
        {
            var retorno = await _ordemService.Delete(id);

            if (retorno != null)
                return RedirectToAction("Index");
            else
                throw new Exception("Error");
        }

        [HttpGet]
        public async Task<IActionResult> Alterar(int id)
        {
            var lista = await _ordemService.GetOrdemById(id);
            return View(lista);
        }

        [HttpPost]
        public async Task<ActionResult> Alterar(Ordem ordem)
        {

            var retorno = await _ordemService.Update(ordem);

            if (retorno != null)
                return RedirectToAction("Index");
            else
                throw new Exception("Error");


        }

    }
}
