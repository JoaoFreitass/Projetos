﻿using API_Ordem.Context;
using API_Ordem.Model;
using Microsoft.EntityFrameworkCore;
using System.IO;
using System.Runtime.Intrinsics.Arm;

namespace API_Ordem.Interface
{
    public class OrdemRepository : IOrdemRepository
    {
        private readonly AppDbContext _context;

        public OrdemRepository(AppDbContext context)
        {
            _context = context;
        }
        public async Task<IEnumerable<Ordem>> GetOrdem()
        {
            try
            {
                return await _context.Ordem.ToListAsync();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw;
            }
        }
        public async Task<Ordem> GetOrdemById(int id)
        {
            try
            {
                var jogo = await _context.Ordem.FindAsync(id);
                return jogo;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw;
            }
        }
        public async Task CreateOrdem(Ordem ordem)
        {
            _context.Ordem.Add(ordem);
            await _context.SaveChangesAsync();
        }
        public async Task UpdateOrdem(Ordem ordem)
        {
            _context.Entry(ordem).State = EntityState.Modified;
            await _context.SaveChangesAsync();

        }

        public async Task<bool> DeleteOrdem(int id)
        {
            Ordem ordem = await GetOrdemById(id);

            if (ordem == null) throw new System.Exception("Erro ao Excluir");

            _context.Ordem.Remove(ordem);
            await _context.SaveChangesAsync();

            return true;
        }



    }
}
