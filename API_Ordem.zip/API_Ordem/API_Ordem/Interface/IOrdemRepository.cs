﻿using API_Ordem.Model;

namespace API_Ordem.Interface
{
    public interface IOrdemRepository
    {
        Task<IEnumerable<Ordem>> GetOrdem();
        Task<Ordem> GetOrdemById(int id);
        Task CreateOrdem(Ordem ordem);
        Task UpdateOrdem(Ordem ordem);
        Task<bool> DeleteOrdem(int id);
    }
}
