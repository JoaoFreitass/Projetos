﻿using API_Ordem.Interface;
using API_Ordem.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.IO;

namespace API_Ordem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrdemController : ControllerBase
    {
        private IOrdemRepository _ordemRepository;

        public OrdemController(IOrdemRepository ordemRepository)
        {
            _ordemRepository = ordemRepository;
        }


        [HttpGet, Route("GetOrdem")]
        public async Task<ActionResult<IAsyncEnumerable<Ordem>>> GetOrdems()
        {
            try
            {
                var Ordems = await _ordemRepository.GetOrdem();
                return Ok(Ordems);

            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Erro 500");
            }
        }

        [HttpGet, Route("GetOrdemById/{id}")]
        public async Task<ActionResult<Ordem>> GetOrdemById(int id)
        {
            try
            {

                var Ordems = await _ordemRepository.GetOrdemById(id);

                if (Ordems == null)
                {
                    return NotFound($"Não existe Ordems com o {id}");
                }

                return Ok(Ordems);

            }
            catch
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Erro 500");

            }
        }

        [HttpPost, Route("Create")]
        public async Task<ActionResult> Create(Ordem Ordem)
        {
            try
            {
                await _ordemRepository.CreateOrdem(Ordem);
                return CreatedAtAction(nameof(GetOrdems), new { id = Ordem.ID }, Ordem);
            }
            catch
            {
                return BadRequest("Request inválido");
            }

        }

        [HttpPut, Route("Update/{id}")]
        public async Task<ActionResult> Update(int id, [FromBody] Ordem Ordem)
        {
            try
            {
                if (Ordem.ID == id)
                {
                    await _ordemRepository.UpdateOrdem(Ordem);
                    return Ok($"Ordem com id= {id} foi atualizado");
                }
                else
                {

                    return BadRequest("Dados inexistentes");
                }
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Erro 500");
            }

        }


        [HttpDelete, Route("Delete/{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            try
            {
                //var ordem = await _ordemRepository.GetOrdemById(id);
                if (id != null)
                {
                    await _ordemRepository.DeleteOrdem(id);
                    return Ok($"Ordem com id= {id} foi excluido");
                }
                else
                {
                    return NotFound($"Alunos com id = {id} não existe");
                }

            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Erro 500");
            }

        }
    }
}
