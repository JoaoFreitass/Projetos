﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace API_Ordem.Model
{

    [Table("Ordem")]
    public class Ordem
    {
        [Key]
        public int ID { get; set; }

        [Required]
        public string Cliente { get; set; }

        [Required]
        public string Nchamado { get; set; }

        [Required]
        public string Comentario { get; set; }

        [Required]
        public string Descrição { get; set; }

        [Required]
        public string Status { get; set; }

        [Required]

        public string Responsabilidade { get; set; }

        [Required]
        public string TipoErro { get; set; }

        [Required]
        public string GrupoEncaminhado { get; set; }

        [Required]
        public string AnalistaResp { get; set; }

    }

}
