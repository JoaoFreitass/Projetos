﻿using API_Ordem.Model;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Runtime.Intrinsics.Arm;

namespace API_Ordem.Context
{
    public class AppDbContext : DbContext
    {
        public AppDbContext()
        {
        }
        
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            JToken jAppSettings = JToken.Parse(File.ReadAllText(Path.Combine(Environment.CurrentDirectory, "appsettings.json")));
            optionsBuilder.UseSqlServer(jAppSettings["ConnectionStrings"]["DefaultConnection"].ToString());
            optionsBuilder.UseLazyLoadingProxies();
        }
        public DbSet<Ordem> Ordem { get; set; }
    }
}
